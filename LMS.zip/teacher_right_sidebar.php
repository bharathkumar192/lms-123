<div class="span3" id="">
	<div class="row-fluid">
		<?php include('add_class.php'); ?>	
	</div>
</div>